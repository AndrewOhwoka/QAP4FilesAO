# Comment
# Program is to calculate new insurance policy
# for One Stop Insurance Company
# Date written: Nov. 20th, 2023 - Nov. 30th, 2023
# Author: Andrew Ohwoka

# imports
import datetime
import FormatValues as FV

# Constants
NEXT_POLICY_NUMBER = 1944
BASIC_PREMIUM = 869.00
DISCOUNT_FOR_ADDITIONAL_CARS = 0.25
COST_OF_EXTRA_LIABILITY_COVERAGE = 130.00
COST_OF_GLASS_COVERAGE = 86.00
COST_FOR_LOANER_CAR_COVERAGE = 58.00
HST_RATE = 0.15
PROCESSING_FEE_FOR_MONTHLY_PAYMENTS = 39.99

# Functions

def calculateInsurancePremium(numCars, extraLiability, glassCoverage, loanerCar):
    totalPremium = BASIC_PREMIUM

    if numCars >= 2:
        additionalCarsPremium = BASIC_PREMIUM * (1 - DISCOUNT_FOR_ADDITIONAL_CARS) * (numCars - 1)
        totalPremium += additionalCarsPremium

    if extraLiability == 'Y':
        totalPremium += COST_OF_EXTRA_LIABILITY_COVERAGE * numCars
    
    if glassCoverage == 'Y':
        totalPremium += COST_OF_GLASS_COVERAGE * numCars
    
    if loanerCar == 'Y':
        totalPremium += COST_FOR_LOANER_CAR_COVERAGE * numCars
    
    return totalPremium

def calculatemonthlyPayment(totalCost, downPayment):
    totalWithFee = totalCost + PROCESSING_FEE_FOR_MONTHLY_PAYMENTS 

    if downPayment > 0:
        remainingBalance = totalWithFee - downPayment
        monthlyPayment = remainingBalance / 8
    else:
        monthlyPayment = totalWithFee / 8

    return monthlyPayment

def FReceipt(lastName, firstName, phoneNumber):
    # Extracting the first two letters from the last name and first name
    lastNameLetters = lastName[:2].upper()
    firstNameLetters = firstName[:2].upper()

    # Extracting the last three digits from the phone number
    lastThreeDigits = str(phoneNumber)[-4:]

    # Creating the receipt format
    ReceiptValueStr = f"{lastNameLetters}-{firstNameLetters}-{lastThreeDigits}"
    
    return ReceiptValueStr

# Main program
while True:
 
    # Inputs
    firstName = input("Enter customer's first name (END to quit): ").title()
    if firstName.upper()=="END":
        break
    lastName = input("Enter customer's last name: ").title()
    address = input("Enter customer's address: ").title()
    city = input("Enter customer's city: ").title()

    # Validating province using a list
    provLst = ["NL", "NS", "PE", "NB", "QC", "ON", "MB", "SK", "AB", "BC", "YT", "NT", "NV"]
    while True:
        prov = input("Enter the province (XX): ").upper()
        if prov == "":
            print("Error - Province cannot be blank - Please reenter.")
        elif len(prov) != 2:
            print("Error - Province is a 2 digit code - please reenter.")
        elif prov not in provLst:
            print("Error - Not a valid province - please reenter.")
        else:
            break

    postalCode = input("Enter customer's postal code: ").upper()
    phoneNumber = input("Enter customer's phone number: ")
    numCars = int(input("Enter the number of cars being insured: "))
    

    extraLiability = input("Extra liability coverage up to $1000000 (Y/N): ").upper()     
    glassCoverage = input("Glass coverage (Y/N): ").upper()
    loanerCar = input("Loaner car coverage (Y/N): ").upper()

 # Validating payment method using a list
    paymentOptionLst = ["Full", "Monthly", "Down Pay"]
    while True:
        payment = input("Enter payment option (Full, Monthly, or Down Pay): ").title()
        if payment == "":
            print("Error - Payment cannot be blank - Please reenter.")
        elif payment not in paymentOptionLst:
            print("Error - Not a valid payment - please reenter.")
        else:
            break

    downPayment = 0
    if payment == 'Down Pay':
        downPayment = float(input("Enter the amount of the down payment:$ "))

    # Initialize empty lists to store claims' dates and costs
    dates = []
    costs = []
    claimNums = []
    # Specify the number of claims to enter
    for claims in range(1,4):
        claimNum = int(input("Enter the claim number(1,2,3): "))
        date = input("Enter the date of the claim (YYYY-MM-DD): ")
        date= datetime.datetime.strptime(date, "%Y-%m-%d")
        cost = float(input("Enter the cost of the claim:$ "))
        dates.append(date)
        costs.append(cost)
        claimNums.append(claimNum)

    # calculate

    totalPremium = calculateInsurancePremium(numCars, extraLiability, glassCoverage, loanerCar)
    totalHst = totalPremium * HST_RATE
    totalCost = totalPremium + totalHst
    monthlyPayment = calculatemonthlyPayment(totalCost, downPayment)
    ReceiptValueStr = FReceipt(lastName, firstName, phoneNumber)

    # Output

    print()
    print(f"                      One Stop Insurance Company                              ")
    print()
    print(f"-----------------------------------------------------------------------------")
    print()
    print(f"Receipt No.:        {ReceiptValueStr}     ") 
    print(f"Customer:           {firstName} {lastName}                       ")                
    print(f"Address:            {address}, {city}, {prov}, {postalCode}")
    print(f"Phone Number:       {phoneNumber}")
    print(f"Number of Cars:     {numCars}")
    print(f"Extra Liability:    {extraLiability}")
    print(f"Glass Coverage:     {glassCoverage}")
    print(f"Loaner Car Coverage:{loanerCar}")
    print(f"Payment Method:     {payment}")
    print("\nPremium Breakdown:")
    print()
    print(f"Total Premium:      {FV.FDollar2(totalPremium):>10s}")
    print(f"HST (15%):          {FV.FDollar2(totalHst):>10s}")
    print(f"Total Cost:         {FV.FDollar2(totalCost):>10s}")
    print(f"Monthly payment:    {FV.FDollar2(monthlyPayment):>10s}")
    Today = datetime.datetime.now()
    print()
    print(f"      Claims #           Claim Date                 Amount        ") 
    print(f"      -------------------------------------------------------------")
    print(f"          {claimNums[0]:>1d}              {FV.FDateS(dates[0]):>10s}              {FV.FDollar2(costs[0]):>10s}")
    print(f"          {claimNums[1]:>1d}              {FV.FDateS(dates[1]):>10s}              {FV.FDollar2(costs[1]):>10s}")
    print(f"          {claimNums[2]:>1d}              {FV.FDateS(dates[2]):>10s}              {FV.FDollar2(costs[2]):>10s}")
    print(f"      -------------------------------------------------------------")
    print()
    print(f"Invoice Date:       {FV.FDateS(Today)}")
    print(f"First Payment Date: {FV.FDateS(Today + datetime.timedelta(days=1))}")
    print()
    print(f"-----------------------------------------------------------------------------")   
    print()    
        